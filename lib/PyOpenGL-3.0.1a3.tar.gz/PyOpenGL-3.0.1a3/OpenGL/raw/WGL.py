"""Collects the various WGL extensions together"""
from OpenGL.raw._WGL import *
from OpenGL.raw._WGL_ARB import *
from OpenGL.raw._WGL_NV import *
